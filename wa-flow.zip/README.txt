# WhatsApp Flow Railway Deployment

## Steps

1. Generate keys:

openssl genrsa -out private.pem 2048

openssl rsa -in private.pem -pubout -out public.pem

2. Put private.pem inside this folder.

3. Upload contents of public.pem to Meta WhatsApp Flow encryption settings.

4. Upload this folder to GitHub.

5. Deploy to Railway.

6. Railway will provide a public HTTPS URL.

7. Use that URL as your WhatsApp Flow endpoint.

## Local Test

npm install
npm start
